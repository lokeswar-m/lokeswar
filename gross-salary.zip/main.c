#include<stdio.h>
int main()
{
    float km,m,cm,ft,i;
    printf ("enter the kilomemter : ");
    scanf("%f",&km);
    m=km*1000;
    cm=m*100;
    i=cm/2.54;
    ft=i/12;
    printf("\n kM : %0.2f",km);
    printf("\n M  : %0.2f",m);
    printf("\n CM : %0.2f",cm);
    printf("\n IN : %0.2f",i);
    printf("\n FT : %0.2f",ft);

    return 0;
}


